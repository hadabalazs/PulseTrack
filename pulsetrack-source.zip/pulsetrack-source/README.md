# PulseTrack

A self-hosted, offline-first PWA for tracking weekly workouts.

## What it does

- **Weekly tracker** — tick off sessions per day, across multiple sports at once. Swipe left/right to move between weeks.
- **Distance logging** (optional) — record metres per session, with per-sport and rolling-average stats.
- **Weekly goals** — set a distance goal per sport. Changing a goal applies from that week forward, so past weeks keep the goal that was actually active at the time.
- **Cost tracker** — track cost-per-session against a subscription, with break-even progress. Archive a subscription when you renew and keep lifetime stats across every period.
- **Stats** — weekly charts, monthly calendar, exercise breakdown, filterable by workout type over selectable date ranges.
- **Backup & restore** — export/share your data as JSON, restore by merge or replace.

## Data & privacy

There is no backend. Everything lives in the browser's `localStorage` on your device, under four keys:

| Key | Contents |
| --- | --- |
| `workout_tracker_logs` | every logged session |
| `pulsetrack_app_settings` | preferences, weekly goal history, filters |
| `pulsetrack_cost_tracker` | subscriptions and archived periods |
| `pulsetrack_tracker_sports` | which sports show on the tracker |

Uninstalling the PWA does **not** clear this data — it's tied to the site's origin, not the home-screen icon. Clearing site data in the browser, or using "Clear All Data" in Settings, does.

## Stack

React 18 · Vite · Tailwind · Recharts · date-fns · Radix (select) · vaul (drawer)

## Development

```bash
npm install     # first time
npm run dev     # local dev server
npm run build   # production build → dist/
npm run preview # serve the production build locally
```

## Deployment

`netlify.toml` is included, so connecting this repo to Netlify gives automatic
deploys on push. The SPA redirect rule is required — without it, refreshing on
`/stats` returns a 404.

To deploy manually instead: run `npm run build` and drag the `dist/` folder
into Netlify.
